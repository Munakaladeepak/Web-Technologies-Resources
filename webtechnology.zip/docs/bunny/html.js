1)What does HTML stand for?
    a)Home tool Markup language
    b)hyper Text Markup language
    c)Hyper text machine language
    d)Hyper text Markup language
Answer:b
2)choose the correct HTML element forthe largest heading
    a) <head>
    b) <h1>
    c) <h3>
    d)<h6>
Answer: c
3) which character is used to indicate an end tag
   a) *
   b) ^
   c) /
   d) <
ANSWER: c
4) choose the correct HTMC tag for paragraph
   a) <p>
   b) <paragraph>
   c) < body> 
   d) < h1>
Answer: a
5) which of these elements are all <table> elements?
   a) < table><thead><tbody> 
   b) < table><head><td>
   c) < table><body><foot>
   d) < table><thead><body> 
Answer: a
6)How can you make a numbered list?
   a)<list>
   b)<li>
   c)<ol>
   d)<ul>
Answer:c
7)What is the correct HTML for making a radio button?
   a)<input type="radio">
   b)<radio>
   c)<input type="checkbox">
   d)<radio button> 
Answer:a
8)What is the correct HTML for making a checkbox?
a)<check>
b)<input type="checkbox">
c)<input type="radio">
d)<checkbox> 
Answer:b
9)HTML comments start with<!--and end with-->
a)False
b)True
Answer:b
10)What doctype is correct HTML5?
a)<!DOCTYPE html>
b)<!DOCTYPE HTML5>
Answer:b
11)What is the correct HTML for inserting an image?
   a)<img src="img.gif" alt="img">
   b)<image src="img.gif" alt="img">
   c)<img href="img.gif" alt="img">
   d)<img alt="img">picture</img>
Answer:b
12)what is the correct HTML for marquee?
  a)<mar>
  b)<marquee>
13)What is the correct HTML for fream?
   a)<frameset>
   b)<framesetrows>
   c)<frame>
   d)</frameset>
Answer:c

